package com.santuariomuerte;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** El altar: al poner el Alma Robada (click derecho) empieza el encuentro. */
public class AltarBlock extends Block {
    public AltarBlock(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        if (!stack.is(ModContent.ALMA_ROBADA.get())) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.literal("El altar espera un Alma Robada...")
                        .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
            if (EncounterManager.start(sl, pos, sp) && !player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
