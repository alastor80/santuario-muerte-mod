package com.santuariomuerte;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String PROTO = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SantuarioMuerte.MODID, "main"), () -> PROTO, PROTO::equals, PROTO::equals);

    public static void init() {
        CH.registerMessage(0, CinematicPacket.class, CinematicPacket::encode, CinematicPacket::decode, CinematicPacket::handle);
    }
}
