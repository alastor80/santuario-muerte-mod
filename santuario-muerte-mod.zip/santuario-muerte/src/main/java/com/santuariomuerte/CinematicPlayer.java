package com.santuariomuerte;

import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import com.mojang.blaze3d.platform.NativeImage;

/**
 * Reproduce la animación como secuencia de imágenes (sin decodificador de video).
 * Optimizado para celular: una sola textura en memoria, se carga un frame por vez
 * y solo cuando cambia (12 fps), con el audio aparte en .ogg.
 *
 * Para cambiar la calidad: regenerá los frames en
 * assets/santuariomuerte/textures/cinematica/curacion/f001.png ... y ajustá estas constantes.
 */
public class CinematicPlayer {
    static final int FRAMES = 120;
    static final int FPS = 12;
    static final int W = 480;
    static final int H = 216;

    private static final ResourceLocation TEX = new ResourceLocation(SantuarioMuerte.MODID, "cinematica/curacion_frame");
    private static final SoundEvent SOUND =
            SoundEvent.createVariableRangeEvent(new ResourceLocation(SantuarioMuerte.MODID, "cinematica.curacion"));

    private static DynamicTexture tex;
    private static long startNs;
    private static int shown = -1;
    private static boolean playing;

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (tex == null) {
            tex = new DynamicTexture(W, H, true);
            mc.getTextureManager().register(TEX, tex);
        }
        playing = true;
        shown = -1;
        startNs = System.nanoTime();
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SOUND, 1.0f));
    }

    public static void stop() {
        if (!playing) return;
        playing = false;
        shown = -1;
        Minecraft.getInstance().getSoundManager().stop(SOUND.getLocation(), null);
    }

    public static void render(GuiGraphics g, int sw, int sh) {
        if (!playing || tex == null) return;
        int frame = (int) ((System.nanoTime() - startNs) / 1_000_000_000.0 * FPS);
        if (frame >= FRAMES) frame = FRAMES - 1;
        if (frame != shown) load(frame);

        float scale = Math.min(sw / (float) W, sh / (float) H);
        int dw = Math.round(W * scale);
        int dh = Math.round(H * scale);
        g.blit(TEX, (sw - dw) / 2, (sh - dh) / 2, dw, dh, 0f, 0f, W, H, W, H);
    }

    private static void load(int frame) {
        shown = frame; // aunque falle, no reintenta el mismo frame en bucle
        ResourceLocation rl = new ResourceLocation(SantuarioMuerte.MODID,
                String.format("textures/cinematica/curacion/f%03d.png", frame + 1));
        try (InputStream in = Minecraft.getInstance().getResourceManager().open(rl);
             NativeImage img = NativeImage.read(in)) {
            if (img.getWidth() == W && img.getHeight() == H && tex.getPixels() != null) {
                tex.getPixels().copyFrom(img);
                tex.upload();
            }
        } catch (Exception ignored) {
        }
    }
}
