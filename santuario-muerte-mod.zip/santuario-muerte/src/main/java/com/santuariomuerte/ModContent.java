package com.santuariomuerte;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModContent {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SantuarioMuerte.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SantuarioMuerte.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SantuarioMuerte.MODID);

    public static final RegistryObject<Block> ALTAR = BLOCKS.register("altar_muerte",
            () -> new AltarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(50.0F, 1200.0F)
                    .sound(SoundType.DEEPSLATE)
                    .requiresCorrectToolForDrops()
                    .lightLevel(s -> 7)));

    public static final RegistryObject<Item> ALTAR_ITEM = ITEMS.register("altar_muerte",
            () -> new BlockItem(ALTAR.get(), new Item.Properties()));

    public static final RegistryObject<Item> ALMA_ROBADA = ITEMS.register("alma_robada", AlmaRobadaItem::new);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("principal",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.santuariomuerte"))
                    .icon(() -> new ItemStack(ALMA_ROBADA.get()))
                    .displayItems((params, out) -> {
                        out.accept(ALTAR_ITEM.get());
                        out.accept(ALMA_ROBADA.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
