package com.santuariomuerte;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Lado cliente de las animaciones: oculta TODO el HUD (incluida la barra del jefe),
 * tapa la pantalla de negro y reproduce la animación (frames + audio) con CinematicPlayer.
 */
@Mod.EventBusSubscriber(modid = SantuarioMuerte.MODID, value = Dist.CLIENT)
public class ClientCinematic {
    private static boolean active;
    private static int left;

    /** Gancho para el video: se dibuja arriba del negro mientras dura la animación. */
    public interface Renderer {
        void render(GuiGraphics g, int width, int height, float partialTick);
    }

    public static Renderer renderer = null;

    public static void set(boolean on, int ticks) {
        if (on && !active) CinematicPlayer.start();
        if (!on && active) CinematicPlayer.stop();
        active = on;
        left = ticks + 40; // margen de seguridad por si se pierde el paquete de "apagar"
    }

    @SubscribeEvent
    public static void onOverlayPre(RenderGuiOverlayEvent.Pre e) {
        if (active) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onGuiPost(RenderGuiEvent.Post e) {
        if (!active) return;
        GuiGraphics g = e.getGuiGraphics();
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        g.fill(0, 0, w, h, 0xFF000000);
        CinematicPlayer.render(g, w, h);
        if (renderer != null) renderer.render(g, w, h, e.getPartialTick());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && active && --left <= 0) {
            active = false;
            CinematicPlayer.stop();
        }
    }
}
