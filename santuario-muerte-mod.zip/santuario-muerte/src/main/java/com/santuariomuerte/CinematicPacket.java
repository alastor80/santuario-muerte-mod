package com.santuariomuerte;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: empieza/termina una animación (pantalla negra, HUD oculto). */
public class CinematicPacket {
    final boolean on;
    final int ticks;

    public CinematicPacket(boolean on, int ticks) {
        this.on = on;
        this.ticks = ticks;
    }

    public static void encode(CinematicPacket m, FriendlyByteBuf b) {
        b.writeBoolean(m.on);
        b.writeInt(m.ticks);
    }

    public static CinematicPacket decode(FriendlyByteBuf b) {
        return new CinematicPacket(b.readBoolean(), b.readInt());
    }

    public static void handle(CinematicPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientCinematic.set(m.on, m.ticks)));
        ctx.get().setPacketHandled(true);
    }
}
