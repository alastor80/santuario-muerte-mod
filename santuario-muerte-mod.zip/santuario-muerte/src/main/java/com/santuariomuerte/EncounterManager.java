package com.santuariomuerte;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * Todo el encuentro contra La Muerte (The Immortal de EEEAB's Mobs).
 *
 * Flujo:
 *  APPEARING  -> altar vibra, aparece el jefe (quieto, invulnerable)
 *  INTRO      -> subtítulos del diálogo inicial
 *  FIGHT1     -> pelea normal; el jefe no puede bajar del piso de vida
 *  HEAL       -> animación 1: HUD oculto, todos congelados, se cura a la mitad
 *  FIGHT2     -> pelea de nuevo
 *  FROZEN_TALK-> todos congelados menos Omega Nas; el jefe habla
 *  CHAT       -> Omega Nas escribe por chat; el jefe responde si hay respuesta
 *  AWAIT_TRIGGER -> Omega Nas habla con los chicos; "manténganse lejos" activa la pelea
 *  FIGHT_OMEGA-> los demás a 15 bloques, el jefe ataca solo a Omega Nas
 *  DYING      -> muerte épica por código y vuelta al mundo
 */
@Mod.EventBusSubscriber(modid = SantuarioMuerte.MODID)
public class EncounterManager {

    // ===================== AJUSTES (tocá acá) =====================
    /** ID de la entidad en EEEAB's Mobs. Confirmalo en el juego con /summon eeeabsmobs: + Tab. */
    public static final String BOSS_ID = "eeeabsmobs:immortal";
    public static final String BOSS_NAME = "La Muerte";
    /** Nombres de usuario de Omega Nas (sin espacios, en minúscula). Acepta cualquiera de estos. */
    static final String[] OMEGA_NAMES = {"omeganaz", "omeganas"};

    static final ResourceKey<Level> DIM = ResourceKey.create(Registries.DIMENSION,
            new ResourceLocation(SantuarioMuerte.MODID, "oscuridad"));
    /** Centro de la arena en la dimensión (el piso termina en y=2, así que se para en y=3). */
    static final BlockPos ARENA = new BlockPos(0, 3, 0);

    static final double SPAWN_RADIUS = 6.0;     // donde aparecen los jugadores
    static final double WATCH_RADIUS = 15.0;    // donde quedan mirando la pelea final
    static final float LOW_HP = 0.12f;          // a este % de vida pasa a la siguiente etapa
    static final float HP_FLOOR = 0.10f;        // el jefe no puede bajar de este % en fase 1 y 2
    static final float HEAL_TO = 0.50f;         // vida a la que se cura en la animación 1
    static final float HEAL_BIT = 0.15f;        // cura chica antes de pelear con Omega Nas
    static final int HEAL_TICKS = 205;          // duración del video (~10,03 s)

    static final String[] INTRO = {
            "Así que son ustedes...",
            "los que creyeron que podían devorar almas sin pagar el precio.",
            "Soy el fin de todo lo que vive, y ustedes todavía respiran.",
            "Ya no puedo arrebatarles la vida de un soplo...",
            "entonces la tomaré golpe a golpe."
    };
    static final String[] TALK = {
            "Basta.",
            "Ya jugué lo suficiente con ustedes.",
            "Un solo golpe. Es todo lo que necesito."
    };

    record Step(String[] keys, String reply) {}

    /** Charla por chat: si lo que escribe Omega Nas contiene una palabra clave, responde. Si no, silencio. */
    static final Step[] CHAT = {
            new Step(new String[]{"basta"}, "¿Omega Nas? Jajajaja... no lo puedo creer."),
            new Step(new String[]{"sufrido", "culpa"}, "Sigues resentido por ser alguien reemplazable."),
            new Step(new String[]{"pasado"}, "Jajajajaja... patético. Siempre fuiste patético."),
            new Step(new String[]{"mates", "matar"}, "Eres el único que se mueve. ¿De verdad crees que puedes detenerme?"),
            new Step(new String[]{"vencer", "derrotar"}, "Inténtalo. Muchos lo hicieron... ninguno cuenta cómo terminó.")
    };

    /** Frases que activan la pelea final (se comparan sin tildes y en minúscula). */
    static final String[] TRIGGER = {"mantenganse", "mantengase", "interrumpan", "alejense"};
    // ==============================================================

    enum Phase { IDLE, APPEARING, INTRO, FIGHT1, HEAL, FIGHT2, FROZEN_TALK, CHAT, AWAIT_TRIGGER, FIGHT_OMEGA, DYING }

    record Ret(ResourceKey<Level> dim, double x, double y, double z, float yRot, float xRot) {}

    static Phase phase = Phase.IDLE;
    static int t;                       // ticks dentro de la fase actual
    static MinecraftServer server;
    static Mob boss;
    static UUID bossId;
    static final Set<UUID> frozen = new HashSet<>();
    static final Map<UUID, Ret> returns = new HashMap<>();
    static Ret fallback;
    static final Queue<Runnable> queue = new ConcurrentLinkedQueue<>();
    static int chatIdx;
    static String pendingReply;
    static int pendingDelay;
    static float healStart;
    static boolean allowDeath;
    static int lost;

    // ------------------------------------------------------------------ inicio

    public static boolean start(ServerLevel from, BlockPos altar, ServerPlayer starter) {
        MinecraftServer srv = from.getServer();
        if (phase != Phase.IDLE) {
            starter.displayClientMessage(Component.literal("La Muerte ya fue invocada.").withStyle(ChatFormatting.RED), true);
            return false;
        }
        ServerLevel dim = srv.getLevel(DIM);
        if (dim == null) {
            starter.sendSystemMessage(Component.literal("No se encontró la dimensión del santuario (santuariomuerte:oscuridad)."));
            return false;
        }
        if (!ForgeRegistries.ENTITY_TYPES.containsKey(new ResourceLocation(BOSS_ID))) {
            starter.sendSystemMessage(Component.literal("No se encontró la entidad " + BOSS_ID + ". ¿Está instalado EEEAB's Mobs?"));
            return false;
        }
        if (dim.getDifficulty() == Difficulty.PEACEFUL) {
            starter.sendSystemMessage(Component.literal("El mundo está en Pacífico: el jefe desaparecería. Cambiá la dificultad."));
            return false;
        }

        server = srv;
        frozen.clear();
        returns.clear();
        queue.clear();
        chatIdx = 0;
        pendingReply = null;
        allowDeath = false;
        lost = 0;
        fallback = new Ret(from.dimension(), altar.getX() + 0.5, altar.getY() + 1.0, altar.getZ() + 0.5, 0f, 0f);

        List<ServerPlayer> players = new ArrayList<>(srv.getPlayerList().getPlayers());
        int n = Math.max(1, players.size());
        for (int i = 0; i < players.size(); i++) {
            ServerPlayer p = players.get(i);
            returns.put(p.getUUID(), new Ret(p.level().dimension(), p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot()));
            double ang = Math.PI * 2 * i / n;
            double x = ARENA.getX() + 0.5 + Math.cos(ang) * SPAWN_RADIUS;
            double z = ARENA.getZ() + 0.5 + Math.sin(ang) * SPAWN_RADIUS;
            p.teleportTo(dim, x, ARENA.getY(), z, facing(x, z), 0f);
            freeze(p);
        }
        setPhase(Phase.APPEARING);
        return true;
    }

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || phase == Phase.IDLE) return;
        server = ServerLifecycleHooks.getCurrentServer();
        ServerLevel dim = server == null ? null : server.getLevel(DIM);
        if (dim == null) {
            reset();
            return;
        }
        Runnable r;
        while ((r = queue.poll()) != null) r.run();
        if (phase == Phase.IDLE) return;

        t++;
        if (t % 10 == 0) refreshFrozen(dim);

        if (phase != Phase.APPEARING && phase != Phase.DYING && (boss == null || boss.isRemoved())) {
            abort();
            return;
        }

        switch (phase) {
            case APPEARING -> tickAppearing(dim);
            case INTRO -> tickIntro(dim);
            case FIGHT1, FIGHT2 -> tickFight(dim);
            case HEAL -> tickHeal(dim);
            case FROZEN_TALK -> tickTalk(dim);
            case CHAT -> tickChat(dim);
            case FIGHT_OMEGA -> tickOmegaFight(dim);
            case DYING -> tickDying(dim);
            default -> { }
        }
    }

    static void tickAppearing(ServerLevel dim) {
        Vec3 c = center();
        if (t % 3 == 0) dim.sendParticles(ParticleTypes.SOUL, c.x, c.y + 0.2, c.z, 4, 2.5, 0.2, 2.5, 0.01);
        if (t % 20 == 1) dim.playSound(null, ARENA, SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 4f, 0.5f);
        if (t == 60) lightning(dim);
        if (t == 80) {
            if (!spawnBoss(dim)) {
                broadcast(dim, "No se pudo invocar a " + BOSS_ID + ".");
                abort();
                return;
            }
            setPhase(Phase.INTRO);
        }
    }

    static void tickIntro(ServerLevel dim) {
        final int per = 80;
        int i = (t - 1) / per;
        if ((t - 1) % per == 0 && i < INTRO.length) say(dim, INTRO[i], per - 4);
        if (t == 1 + INTRO.length * per) {
            for (ServerPlayer p : dim.players()) unfreeze(p);
            boss.setNoAi(false);
            boss.setInvulnerable(false);
            setPhase(Phase.FIGHT1);
        }
    }

    static void tickFight(ServerLevel dim) {
        if (ratio() <= LOW_HP) {
            if (phase == Phase.FIGHT1) startHeal(dim);
            else startTalk(dim);
        }
    }

    // --- animación 1: curación (video en el cliente) ---

    static void startHeal(ServerLevel dim) {
        setPhase(Phase.HEAL);
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setTarget(null);
        healStart = boss.getHealth();
        for (ServerPlayer p : dim.players()) {
            freeze(p);
            sendCinematic(p, true, HEAL_TICKS);
        }
    }

    static void tickHeal(ServerLevel dim) {
        float goal = boss.getMaxHealth() * HEAL_TO;
        float k = Math.min(1f, t / (float) HEAL_TICKS);
        boss.setHealth(Mth.lerp(k, healStart, goal));
        if (t >= HEAL_TICKS) {
            for (ServerPlayer p : dim.players()) {
                unfreeze(p);
                sendCinematic(p, false, 0);
            }
            boss.setNoAi(false);
            boss.setInvulnerable(false);
            setPhase(Phase.FIGHT2);
        }
    }

    // --- congelamiento + charla ---

    static void startTalk(ServerLevel dim) {
        setPhase(Phase.FROZEN_TALK);
        boss.setNoAi(true);
        boss.setInvulnerable(true);
        boss.setTarget(null);
        for (ServerPlayer p : dim.players()) {
            if (!isOmega(p)) freeze(p);
        }
    }

    static void tickTalk(ServerLevel dim) {
        final int per = 70;
        int i = (t - 1) / per;
        if ((t - 1) % per == 0 && i < TALK.length) say(dim, TALK[i], per - 4);
        if (t == 1 + TALK.length * per + 10) {
            chatIdx = 0;
            pendingReply = null;
            setPhase(Phase.CHAT);
        }
    }

    static void tickChat(ServerLevel dim) {
        if (pendingReply != null && --pendingDelay <= 0) {
            String r = pendingReply;
            pendingReply = null;
            chatBoss(dim, r);
            say(dim, r, 70);
            dim.playSound(null, ARENA, SoundEvents.WITHER_AMBIENT, SoundSource.HOSTILE, 3f, 0.5f);
            if (chatIdx >= CHAT.length) setPhase(Phase.AWAIT_TRIGGER);
        }
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        if (phase != Phase.CHAT && phase != Phase.AWAIT_TRIGGER) return;
        ServerPlayer p = e.getPlayer();
        if (!isOmega(p) || p.level().dimension() != DIM) return;
        String text = norm(e.getRawText());
        queue.add(() -> handleOmegaChat(text));
    }

    static void handleOmegaChat(String text) {
        if (phase == Phase.CHAT) {
            if (pendingReply == null && chatIdx < CHAT.length && containsAny(text, CHAT[chatIdx].keys())) {
                pendingReply = CHAT[chatIdx].reply();
                pendingDelay = 30;
                chatIdx++;
            }
        } else if (phase == Phase.AWAIT_TRIGGER && containsAny(text, TRIGGER)) {
            ServerLevel dim = server == null ? null : server.getLevel(DIM);
            if (dim != null) beginOmegaFight(dim);
        }
    }

    // --- pelea final contra Omega Nas ---

    static void beginOmegaFight(ServerLevel dim) {
        ServerPlayer omega = findOmega(dim);
        if (omega == null) return;
        List<ServerPlayer> others = new ArrayList<>();
        for (ServerPlayer p : dim.players()) {
            if (!isOmega(p)) others.add(p);
        }
        Vec3 c = center();
        int n = Math.max(1, others.size());
        for (int i = 0; i < others.size(); i++) {
            ServerPlayer p = others.get(i);
            double ang = Math.PI * 2 * i / n;
            double x = c.x + Math.cos(ang) * WATCH_RADIUS;
            double z = c.z + Math.sin(ang) * WATCH_RADIUS;
            p.teleportTo(dim, x, ARENA.getY(), z, facing(x, z), 0f);
            freeze(p);
        }
        boss.heal(boss.getMaxHealth() * HEAL_BIT);
        boss.setNoAi(false);
        boss.setInvulnerable(false);
        boss.setTarget(omega);
        lost = 0;
        setPhase(Phase.FIGHT_OMEGA);
    }

    static void tickOmegaFight(ServerLevel dim) {
        if (t % 10 != 0) return;
        ServerPlayer o = findOmega(dim);
        if (o != null && o.isAlive()) {
            boss.setTarget(o);
            lost = 0;
        } else if (++lost > 20) { // ~10 s sin Omega Nas
            broadcast(dim, "La Muerte venció.");
            abort();
        }
    }

    // --- muerte épica ---

    static void startDying() {
        if (phase != Phase.FIGHT_OMEGA || boss == null) return;
        setPhase(Phase.DYING);
        boss.setHealth(1f);
        boss.setInvulnerable(true);
        boss.setNoAi(true);
        boss.setTarget(null);
    }

    static void tickDying(ServerLevel dim) {
        Vec3 c = center();
        if (t == 1) {
            say(dim, "Así que... así se siente el final.", 90);
            for (ServerPlayer p : dim.players()) {
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 140, 0, false, false, false));
            }
            dim.playSound(null, ARENA, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 5f, 0.5f);
        }
        if (t < 100 && boss != null && !boss.isRemoved()) {
            double a = t * 0.35;
            for (int k = 0; k < 3; k++) {
                double ang = a + k * 2.094;
                dim.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                        c.x + Math.cos(ang) * 1.6, c.y + (t % 40) * 0.1, c.z + Math.sin(ang) * 1.6, 1, 0, 0.05, 0, 0.0);
            }
            if (t % 5 == 0) {
                dim.sendParticles(ParticleTypes.SCULK_SOUL, boss.getX(), boss.getY() + 1.5, boss.getZ(), 3, 0.6, 0.8, 0.6, 0.03);
            }
            float yaw = boss.getYRot() + t * 0.25f;
            boss.setYRot(yaw);
            boss.yBodyRot = yaw;
            boss.yHeadRot = yaw;
        }
        if (t < 100 && t % 25 == 0) {
            dim.playSound(null, ARENA, SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 4f, 0.5f + t * 0.01f);
        }
        if (t == 40 || t == 70) lightning(dim);
        if (t == 100) {
            dim.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y + 1.5, c.z, 1, 0, 0, 0, 0);
            dim.sendParticles(ParticleTypes.SOUL, c.x, c.y + 1.5, c.z, 150, 1.5, 1.5, 1.5, 0.25);
            dim.playSound(null, ARENA, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 6f, 0.6f);
            dim.playSound(null, ARENA, SoundEvents.ENDER_DRAGON_DEATH, SoundSource.HOSTILE, 6f, 0.7f);
            lightning(dim);
            allowDeath = true;
            if (boss != null && !boss.isRemoved()) {
                boss.setInvulnerable(false);
                boss.hurt(dim.damageSources().genericKill(), Float.MAX_VALUE);
            }
        }
        if (t == 180) {
            returnAll(dim);
            reset();
        }
    }

    // ------------------------------------------------------------------ protección del jefe

    @SubscribeEvent
    public static void onBossHurt(LivingHurtEvent e) {
        if (phase == Phase.IDLE || boss == null || !e.getEntity().getUUID().equals(bossId)) return;
        float hp = boss.getHealth();
        float max = boss.getMaxHealth();
        switch (phase) {
            case FIGHT1, FIGHT2 -> {
                float allowed = hp - max * HP_FLOOR;
                if (allowed <= 0) e.setCanceled(true);
                else if (e.getAmount() > allowed) e.setAmount(allowed);
            }
            case FIGHT_OMEGA -> {
                float allowed = hp - 1f;
                if (e.getAmount() >= allowed) {
                    queue.add(EncounterManager::startDying);
                    if (allowed <= 0) e.setCanceled(true);
                    else e.setAmount(allowed);
                }
            }
            case DYING -> {
                if (!allowDeath) e.setCanceled(true);
            }
            default -> e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onBossDeath(LivingDeathEvent e) {
        if (phase == Phase.IDLE || boss == null || !e.getEntity().getUUID().equals(bossId)) return;
        if (phase == Phase.DYING && allowDeath) return;
        e.setCanceled(true);
        boss.setHealth(1f);
        if (phase == Phase.FIGHT_OMEGA) queue.add(EncounterManager::startDying);
    }

    // ------------------------------------------------------------------ jugadores congelados

    @SubscribeEvent
    public static void onFrozenAttacked(LivingAttackEvent e) {
        if (!frozen.contains(e.getEntity().getUUID())) return;
        if (!e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (frozen.contains(e.getEntity().getUUID())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem e) {
        if (frozen.contains(e.getEntity().getUUID())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (frozen.contains(e.getEntity().getUUID())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract e) {
        if (frozen.contains(e.getEntity().getUUID())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        if (frozen.contains(e.getEntity().getUUID())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (frozen.contains(e.getPlayer().getUUID())) e.setCanceled(true);
    }

    // ------------------------------------------------------------------ comandos de prueba

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("santuariomuerte")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("reset").executes(c -> {
                    abort();
                    c.getSource().sendSuccess(() -> Component.literal("Encuentro cancelado."), true);
                    return 1;
                }))
                .then(Commands.literal("start").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    start(p.serverLevel(), p.blockPosition(), p);
                    return 1;
                })));
    }

    // ------------------------------------------------------------------ utilidades

    static void setPhase(Phase p) {
        phase = p;
        t = 0;
    }

    static Vec3 center() {
        return Vec3.atBottomCenterOf(ARENA);
    }

    static float facing(double x, double z) {
        double dx = ARENA.getX() + 0.5 - x;
        double dz = ARENA.getZ() + 0.5 - z;
        return (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
    }

    static float ratio() {
        return boss.getHealth() / boss.getMaxHealth();
    }

    static boolean spawnBoss(ServerLevel dim) {
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(BOSS_ID));
        Entity en = type == null ? null : type.create(dim);
        if (!(en instanceof Mob m)) return false;
        Vec3 c = center();
        m.moveTo(c.x, c.y, c.z, 0f, 0f);
        m.finalizeSpawn(dim, dim.getCurrentDifficultyAt(ARENA), MobSpawnType.EVENT, null, null);
        m.setCustomName(Component.literal(BOSS_NAME).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        m.setCustomNameVisible(false);
        m.setPersistenceRequired();
        m.setNoAi(true);
        m.setInvulnerable(true);
        dim.addFreshEntity(m);
        boss = m;
        bossId = m.getUUID();
        return true;
    }

    static void lightning(ServerLevel dim) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(dim);
        if (b == null) return;
        b.moveTo(center());
        b.setVisualOnly(true);
        dim.addFreshEntity(b);
    }

    static boolean isOmega(ServerPlayer p) {
        String name = p.getGameProfile().getName().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        for (String n : OMEGA_NAMES) {
            if (name.equals(n)) return true;
        }
        return false;
    }

    static ServerPlayer findOmega(ServerLevel dim) {
        for (ServerPlayer p : dim.players()) {
            if (isOmega(p)) return p;
        }
        return null;
    }

    static void freeze(ServerPlayer p) {
        frozen.add(p.getUUID());
        applyFreezeEffects(p);
    }

    static void applyFreezeEffects(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 255, false, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 128, false, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 4, false, false, false));
    }

    static void unfreeze(ServerPlayer p) {
        frozen.remove(p.getUUID());
        p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        p.removeEffect(MobEffects.JUMP);
        p.removeEffect(MobEffects.DAMAGE_RESISTANCE);
    }

    static void refreshFrozen(ServerLevel dim) {
        for (ServerPlayer p : dim.players()) {
            if (frozen.contains(p.getUUID())) applyFreezeEffects(p);
        }
    }

    static void sendCinematic(ServerPlayer p, boolean on, int ticks) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new CinematicPacket(on, ticks));
    }

    /** Subtítulo grande en el centro de la pantalla, para todos los de la dimensión. */
    static void say(ServerLevel dim, String text, int ticks) {
        for (ServerPlayer p : dim.players()) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(5, ticks, 10));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(text).withStyle(ChatFormatting.WHITE)));
            p.connection.send(new ClientboundSetTitleTextPacket(Component.empty()));
        }
    }

    static void chatBoss(ServerLevel dim, String text) {
        Component msg = Component.literal("<" + BOSS_NAME + "> ").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE));
        for (ServerPlayer p : dim.players()) p.sendSystemMessage(msg);
    }

    static void broadcast(ServerLevel dim, String text) {
        for (ServerPlayer p : dim.players()) p.sendSystemMessage(Component.literal(text).withStyle(ChatFormatting.GRAY));
    }

    static String norm(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT);
    }

    static boolean containsAny(String text, String[] keys) {
        for (String k : keys) {
            if (text.contains(k)) return true;
        }
        return false;
    }

    static void returnAll(ServerLevel dim) {
        for (ServerPlayer p : new ArrayList<>(dim.players())) {
            unfreeze(p);
            p.removeEffect(MobEffects.DARKNESS);
            sendCinematic(p, false, 0);
            Ret r = returns.getOrDefault(p.getUUID(), fallback);
            ServerLevel target = r == null ? null : server.getLevel(r.dim());
            if (target != null) p.teleportTo(target, r.x(), r.y(), r.z(), r.yRot(), r.xRot());
        }
    }

    /** Cancela todo: devuelve a los jugadores, borra al jefe y deja el sistema libre. */
    static void abort() {
        if (server != null) {
            ServerLevel dim = server.getLevel(DIM);
            if (dim != null) returnAll(dim);
        }
        if (boss != null && !boss.isRemoved()) boss.discard();
        reset();
    }

    static void reset() {
        if (server != null) {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (frozen.contains(p.getUUID())) unfreeze(p);
            }
            Net.CH.send(PacketDistributor.ALL.noArg(), new CinematicPacket(false, 0));
        }
        frozen.clear();
        queue.clear();
        boss = null;
        bossId = null;
        phase = Phase.IDLE;
        t = 0;
        chatIdx = 0;
        pendingReply = null;
        allowDeath = false;
        lost = 0;
    }
}
