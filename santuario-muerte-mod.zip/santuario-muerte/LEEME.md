# Santuario de la Muerte (Forge 1.20.1)

Mod con el altar, el Alma Robada, la dimensión de oscuridad y toda la pelea contra La Muerte
(The Immortal de EEEAB's Mobs). Necesita EEEAB's Mobs instalado en el servidor y en los clientes.

## Qué tiene
- **Altar de la Muerte** (`santuariomuerte:altar_muerte`) y **Alma Robada** (`santuariomuerte:alma_robada`).
  Los conseguís en la pestaña creativa "Santuario de la Muerte" o con `/give @p santuariomuerte:alma_robada`.
- **Dimensión `santuariomuerte:oscuridad`**: cielo y niebla negros, piso de concreto negro.
- **Pelea completa**: aparece, diálogo, fase 1, animación de curación, fase 2, congelamiento, charla por chat
  con Omega Nas, pelea final y muerte épica por código.
- **Comandos (OP)**: `/santuariomuerte start` (prueba sin altar) y `/santuariomuerte reset` (cancela todo).

## Ajustes
Todo está arriba de `EncounterManager.java`, en la sección AJUSTES: ID del jefe, nombres de Omega Nas,
porcentajes de vida, radios, diálogos y palabras clave del chat.

## Pendiente
1. **ID del jefe**: `BOSS_ID = "eeeabsmobs:immortal"` es lo más probable pero no está confirmado.
   En el juego escribí `/summon eeeabsmobs:` y mirá las sugerencias con Tab.
2. **Animación 1 sin mp4**: está como 120 frames (480x216, 12 fps) más el audio en .ogg, dentro de
   `assets/santuariomuerte/textures/cinematica/curacion/` y `sounds/curacion.ogg`. `CinematicPlayer` carga un frame
   por vez en una sola textura, así que no pesa en el celular. Si querés más calidad, regenerá los frames y
   cambiá las constantes de `CinematicPlayer`.
3. **Nombre en la barra de vida**: EEEAB's Mobs tiene un sistema propio de barras de jefe. Si la barra sigue
   diciendo "The Immortal", hay que tocar su lang o su barra.
4. **No está compilado**: se compila con tu GitHub Actions. Si falla, pasame el error y lo corrijo.
